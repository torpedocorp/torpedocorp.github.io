package kr.co.torpedo.camel.sample.component;

import org.apache.camel.spring.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CamelApplicationTest {
	
	
	private static Logger logger = LoggerFactory.getLogger(CamelApplicationTest.class);


	
	public static void main(String args[]) {
		String routeXml = "camel-route.xml";
		Main main = new Main();
		main.setApplicationContextUri(routeXml);
		try {
			main.start();
			Thread.sleep(10000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
