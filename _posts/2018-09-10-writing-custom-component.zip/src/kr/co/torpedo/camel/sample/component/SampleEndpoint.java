package kr.co.torpedo.camel.sample.component;
import org.apache.camel.Consumer;
import org.apache.camel.Processor;
import org.apache.camel.Producer;
import org.apache.camel.impl.DefaultEndpoint;
import org.apache.camel.spi.UriEndpoint;
import org.apache.camel.spi.UriParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@UriEndpoint(firstVersion = "1.4.0", scheme = "sample", title = "sample", syntax = "sample", consumerClass = SampleConsumerDefault.class, label = "sample")
public class SampleEndpoint extends DefaultEndpoint {
	
	public static Logger logger = LoggerFactory.getLogger(SampleEndpoint.class);


	@UriParam(label = "testopt1", description = "testopt1")
	private String testopt1;
	
	@UriParam(label = "testopt2", description = "testopt2")
	private String testopt2;
	
	public String toString(){
		StringBuffer sb = new StringBuffer();
		sb.append("testopt2="+this.testopt2);
		sb.append(" testopt2="+this.testopt2);
		return sb.toString();
	}

	public SampleEndpoint(String uri, SampleComponent component) {
		super(uri, component);
	}

	public SampleEndpoint(String endpointUri) {
		super(endpointUri);
	}

	public Producer createProducer() throws Exception {
		return new SampleProducer(this);
	}

	public Consumer createConsumer(Processor processor) throws Exception {
		return new SampleConsumerPoll(this, processor);
	}

	public boolean isSingleton() {
		return true;
	}

}
