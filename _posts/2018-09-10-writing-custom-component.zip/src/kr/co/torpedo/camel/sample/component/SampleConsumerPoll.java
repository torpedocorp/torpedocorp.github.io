package kr.co.torpedo.camel.sample.component;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.impl.ScheduledPollConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class SampleConsumerPoll extends ScheduledPollConsumer {
    private final SampleEndpoint endpoint;

    private static Logger logger = LoggerFactory.getLogger(SampleConsumerPoll.class);

    
    public SampleConsumerPoll(SampleEndpoint endpoint, Processor processor) {
        super(endpoint, processor);
        this.endpoint = endpoint;
        this.setDelay(10000);
    }

    @Override
    protected int poll() throws Exception {
        Exchange exchange = endpoint.createExchange();
        try {
        	logger.debug("***** SampleConsumerPoll sample consummer polling");
            getProcessor().process(exchange);
            return 1; // number of messages polled
        } finally {
            // log exception if an exception occurred and was not handled
            if (exchange.getException() != null) {
                getExceptionHandler().handleException("Error processing exchange", exchange, exchange.getException());
            }
        }
        
    }
    
}
