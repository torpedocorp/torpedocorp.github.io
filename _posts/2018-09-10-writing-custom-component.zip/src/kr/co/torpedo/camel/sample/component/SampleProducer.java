package kr.co.torpedo.camel.sample.component;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SampleProducer extends DefaultProducer {
    
	public static Logger logger = LoggerFactory.getLogger(DefaultProducer.class);

	 
	 ArrayList<String> columnList = new ArrayList<String>();
	 
	String runSql = "";
	
    private SampleEndpoint endpoint;

    public SampleProducer(SampleEndpoint endpoint) throws IOException {
        super(endpoint);
        this.endpoint = endpoint;
       
    }

    public void process(Exchange exchange) throws Exception {
    	 logger.debug("***** SampleProducer processing ");    	
    }
    
    public static void main(String args[]) throws Exception{
    	String filepath =  "misc/doc/ESB_DATA/test/I015708159999410_IL09001000_B60060010_004504";
    	File file = new File(filepath);
    }

}
