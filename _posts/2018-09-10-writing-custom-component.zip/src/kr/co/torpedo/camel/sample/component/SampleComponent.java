
package kr.co.torpedo.camel.sample.component;

import java.util.Map;

import org.apache.camel.Endpoint;
import org.apache.camel.impl.DefaultComponent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SampleComponent extends DefaultComponent {

	private static Logger logger = LoggerFactory.getLogger(SampleComponent.class);
	
	 
    protected Endpoint createEndpoint(String uri, String remaining, Map<String, Object> parameters) throws Exception {
    	SampleEndpoint endpoint = new SampleEndpoint(uri, this);
        setProperties(endpoint, parameters);
        logger.debug("***** SampleComponent create endpoint ");
        return endpoint;
    }

}
